export class Customer {
    name: String = '';
}
