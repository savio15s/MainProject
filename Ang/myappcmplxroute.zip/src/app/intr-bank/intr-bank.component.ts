import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intr-bank',
  templateUrl: './intr-bank.component.html',
  styleUrls: ['./intr-bank.component.css']
})
export class IntrBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
