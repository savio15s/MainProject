import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fundstranfer',
  templateUrl: './fundstranfer.component.html',
  styleUrls: ['./fundstranfer.component.css']
})
export class FundstranferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
