export class User {
  constructor(
    public id: string,
    public userid: string,
    public password: string) { }
}
