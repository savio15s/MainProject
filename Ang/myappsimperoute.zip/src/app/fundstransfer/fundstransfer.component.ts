import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fundstransfer',
  templateUrl: './fundstransfer.component.html',
  styleUrls: ['./fundstransfer.component.css']
})
export class FundstransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
