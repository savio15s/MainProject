export class ToDo {
    Title: string;
    IsCompleted: boolean;
}
