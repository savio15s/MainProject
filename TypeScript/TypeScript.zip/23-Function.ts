function test()    // function definition 
{ 
   console.log("function called") 
} 
test()            // function invocation