var mytuple=[10,"Hello","World","typeScript"]; //create a  tuple 
console.log("Tuple value at index 0 "+mytuple[0]) 
//update a tuple element 
mytuple[0]=121     
console.log("Tuple value at index 0 changed to   "+mytuple[0]) 