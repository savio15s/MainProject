var num:number=12 
num = 45 * 2
console.log(num)
    