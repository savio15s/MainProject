var a: number=12 
var b:number=10 
 
a=b 
console.log("a=b: "+a)   
 
a+=b 
console.log("a+=b: "+a) 
 
a-=b 
console.log("a-=b: "+a)   
TypeScript 
37 
 
 
a*=b 
console.log("a*=b: "+a)  
 
a/=b 
console.log("a/=b: "+a)   
 
a%=b 
console.log("a%=b: "+a)