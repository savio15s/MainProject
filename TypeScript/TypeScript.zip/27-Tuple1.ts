var mytuple=[10,"Hello"]; //create a tuple 
console.log(mytuple[0]) 
console.log(mytuple[1]) 