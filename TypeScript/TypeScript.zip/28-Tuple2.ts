var tup=[] 
tup[0]=12 
tup[1]=23 
console.log(tup[0]) 
console.log(tup[1])