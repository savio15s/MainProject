var str = '5';
console.log(str + 2);
var str2 = str; //str is now of type number 
console.log(str2 * 2);
