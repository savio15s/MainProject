var num1:number=10  
var num2:number=2 
var res:number=0 
res= num1+num2 
console.log("Sum:        "+ res); 
res=num1-num2; 
console.log("Difference: "+res) 
res=num1*num2 
console.log("Product:    "+res) 
res=num1/num2 
console.log("Quotient:   "+res) 
res=num1%num2 
console.log("Remainder:   "+res) 
num1++ 
console.log("Value of num1 after increment "+num1) 
num2-- 
console.log("Value of num2 after decrement "+num2);