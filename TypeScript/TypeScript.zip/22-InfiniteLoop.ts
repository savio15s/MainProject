for(;;) 
{ 
   console.log(“This is an endless loop”) 
}